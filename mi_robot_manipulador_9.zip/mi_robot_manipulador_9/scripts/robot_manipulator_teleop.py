#!/usr/bin/env python3

from argparse import _VersionAction
from glob import glob
from multiprocessing.connection import Listener
from tkinter.tix import TEXT
from turtle import end_fill
import rospy
import sys
import os.path
from pynput import keyboard
from pynput.keyboard import Key, Listener, KeyCode
from geometry_msgs.msg import Twist
from tkinter.filedialog import asksaveasfile
from tkinter import BOTTOM, Tk,Frame,Button,Label, mainloop,ttk



dataFromRos = Twist()


# presionado y no presionado
def on_press(key):

        #Envia un 1 y esto se traduce en mover la pinza arrriba
        if key == keyboard.Key.up:
            dataFromRos.linear.x = int(3)
           
        #Envia un 1 y esto se traduce en mover la pinza abajo   
        elif key == keyboard.Key.down:
            dataFromRos.linear.x  = int(4)
        
        #Envia un 3 y esto se traduce en mover la pinza a la izquierda 
        elif key == keyboard.Key.left:
            dataFromRos.linear.y = int(1)

        #Envia un 4 y esto se traduce en mover la pinza a la derecha
        elif key == keyboard.Key.right:
            dataFromRos.linear.y = (2)

        #Envia un 5 y esto se traduce en mover la pinza a la hacia adelante
        elif key == KeyCode.from_char('w'):
            dataFromRos.linear.z = int(5)

        #Envia un 6 y esto se traduce en mover la pinza a la hacia atras
        elif key == KeyCode.from_char('s'):
            dataFromRos.linear.z = (6)

        #Envia un 7 y esto se traduce en mover la pinza a la hacia adelante
        elif key == KeyCode.from_char('a'):
            dataFromRos.angular.x = (7)

        #Envia un 7 y esto se traduce en mover la pinza a la hacia adelante
        elif key == KeyCode.from_char('d'):
            dataFromRos.angular.x = int(8)

        elif key == keyboard.Key.esc: 
            sys.exit()


def move(key):
    global dataFromRos
    dataFromRos.linear.x = 0
    dataFromRos.linear.y = 0
    dataFromRos.linear.z = 0
    dataFromRos.angular.x = 0

def main():
    global dataFromRos
    #carga la velocidad elegida por el usuario en dataFromRos.angular.y 
    dataFromRos.angular.y = int(speed_joins)
    rospy.init_node('robot_manipulator_teleop')
    listener = keyboard.Listener(on_press=on_press, on_release=move)
    listener.start()
    loop_rate = rospy.Rate(10)
    #variable con el nombre del topico a usar (velocidad)
    topico_velocidad ='brazoRobotico'
    velocity_publisher = rospy.Publisher(topico_velocidad,Twist, queue_size = 10)

    while not rospy.is_shutdown():
        velocity_publisher.publish(dataFromRos)
        print(dataFromRos)#prueba de que manda
        loop_rate.sleep()


if __name__ == "__main__":
	speed_joins=input('Escriba la velocidad para los joints [4, 25]:')
	main()