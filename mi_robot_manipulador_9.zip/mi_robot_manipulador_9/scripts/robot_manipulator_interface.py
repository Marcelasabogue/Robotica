#!/usr/bin/env python3
from cmath import log10
#from tkinter import _CanvasItemId
from turtle import width
#from matplotlib.backends.backend_tkagg import(FigureCanvasTkAgg, NavigationToolbar2Tk)
from cgitb import text
from doctest import master
from fileinput import close
import threading
import rospy
from geometry_msgs.msg import Vector3
import matplotlib.animation as animation
import matplotlib.pyplot as plt
import numpy as np
from tkinter import *
from mpl_toolkits.mplot3d import axes3d
from matplotlib import style



global position_message


plt.style.use('dark_background')



base = Tk()
base.geometry('300x250')

l1 = 8
l2 = 11

xList = [0]
yList = [0]
zList = [0]


def calcularPosicion(data):
       angulo1 = data.x
       angulo2 = data.y
       angulo3 = data.z
       posx=0
       posz = np.sin(angulo3)*posx
       posx = l1*np.cos(angulo1) + l2*np.cos(angulo1 + angulo2)-posz*np.arctan(angulo3)
       posy = l1*np.sin(angulo1) + l2*np.sin(angulo1+angulo2)
       
       xList.append(posx)
       yList.append(posy)
       zList.append(posz)
       print(posx)
      



def aux():
       fig = plt.figure()
       ani = animation.FuncAnimation(fig, animate, interval = 1000)
       ax1 = fig.add_subplot(111, projection = '3d')
       #ax1.scatter(posx, posy, posz)
       #plt.draw()
       plt.show()


def animate(i):
       plt.plot(xList,yList,zList, marker = 'o')

       
def pulling():
       rospy.init_node('robot_manipulator_teleop', anonymous=True)
       lectorDeAngulos = "lectorDeAngulos"
       rospy.Subscriber(lectorDeAngulos, Vector3, calcularPosicion)
       rospy.spin()

def main():
       t = threading.Thread(target=aux)
       t.start()                                                
       pulling()
       



       
if __name__ == '__main__':
       main()
       
       
