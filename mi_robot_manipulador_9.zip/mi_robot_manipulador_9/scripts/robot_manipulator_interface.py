#!/usr/bin/env python3
from cmath import log10
#from tkinter import _CanvasItemId
from turtle import width
#from matplotlib.backends.backend_tkagg import(FigureCanvasTkAgg, NavigationToolbar2Tk)
from cgitb import text
from doctest import master
from fileinput import close
import threading
import rospy
from geometry_msgs.msg import Vector3
import matplotlib.animation as animation
import matplotlib.pyplot as plt
import numpy as np
from tkinter import *
from mpl_toolkits.mplot3d import axes3d
from matplotlib import style



global position_message


plt.style.use('dark_background')



base = Tk()
base.geometry('300x250')

l1 = 10
l2 = 8

xList = [0]
yList = [0]
zList = [0]
posx=0
posy=0
posz=0

def calcularPosicion(data):
       global posx
       global posy
       global posz

       #servo(1)
       angulo1 = data.y*(np.pi/180)
       #servo(2)
       angulo2 = data.z*(np.pi/180)
       #base
       angulo3 = data.x*(np.pi/180)
       
       posx = abs(l1*np.cos(angulo1) + l2*np.cos(angulo1 + angulo2))
       posy = l1*np.sin(angulo1) + l2*np.sin(angulo1 + angulo2)
       posz = np.sin(angulo3)*posx
       
       xList.append(posx)
       yList.append(posy)
       zList.append(posz)
       print(posx)
       print(posy)
       print(posz)



def aux():
       fig = plt.figure()
       ani = animation.FuncAnimation(fig, animate, interval = 1000)
       #ax1.scatter(posx, posy, posz)
       plt.xlim(-20,20)
       plt.ylim(-20,20)
       plt.minorticks_on()
       plt.grid(b=True, which='minor', color='#999999', linestyle = '-',alpha = 0.2)
       plt.title("Posición End-Efector plano XY", 
            fontdict={'family': 'serif', 
            'color' : 'red',
            'weight': 'bold',
            'size': 18}) 
       plt.xlabel('Coordenada X [cm]', size = 16)
       plt.ylabel('Coordenada Y [cm]', size = 16)
       #plt.draw()
       plt.show()


def animate(i):
       plt.plot(xList,yList, "o", ms=8)
  
def pulling():
       rospy.init_node('robot_manipulator_teleop', anonymous=True)
       lectorDeAngulos = "lectorDeAngulos"
       rospy.Subscriber(lectorDeAngulos, Vector3, calcularPosicion)
       rospy.spin()

def main():
       t = threading.Thread(target=aux)
       t.start()                                                
       pulling()
       



       
if __name__ == '__main__':
       main()
       
       
