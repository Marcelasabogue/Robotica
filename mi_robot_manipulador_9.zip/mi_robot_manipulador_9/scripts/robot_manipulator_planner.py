#!/usr/bin/env python3
import numpy as np
from scipy.optimize import fsolve
import rospy
import math as mt
from geometry_msgs.msg import Vector3

l1 = 11
l2 = 8
pm = np.array([+1, -1])

posx = float(input("Introduzca su posicion en x:"))
posy = float(input("Introduzca su posicion en y:"))
posz = float(input("Introduzca su posicion en z:"))

def calculoAngulo(posicionx, posiciony, posicionz):
    
    #Segundo eje
    anguloServo2 = mt.acos((1/(2*l1*l2))*((posicionx**2 + posiciony**2) - (l1**2 + l2**2)))
    anguloServo2 = mt.asin(pm[1]*mt.sqrt(1 - (mt.cos(anguloServo2))**2))
    #Primer eje
    anguloServo1 = mt.acos((1/(posicionx**2 + posiciony**2))*(posicionx*(l1 + l2*mt.cos(anguloServo2)) + pm[1]*posiciony*l2*(mt.sqrt(1 - (mt.cos(anguloServo2))**2))))
    anguloServo1 = mt.asin((1/(posicionx**2 + posiciony**2))*(posiciony*(l1 + l2*mt.cos(anguloServo2)) + pm[1]*posicionx*l2*(mt.sqrt(1 - (mt.cos(anguloServo2))**2))))
   
    longitudExtension = l1**2+l2**2-2*l1*l2*mt.cos(anguloServo1)

   
    #Base
    anguloServo3 = mt.atan(posicionz/longitudExtension)
    if posy >= 2:
      return int(anguloServo2*(180/mt.pi)), int(anguloServo1*(180/mt.pi)), int(anguloServo3*(180/mt.pi))
    elif posy <=2:
      return int(anguloServo2*(180/mt.pi)), int(anguloServo1*(180/mt.pi)),int(anguloServo3*(180/mt.pi))
 
   
 
def main():
  rospy.init_node('robot_manipulator_planner', anonymous = False)
# rospy.subscriber('posicionCamaras', anonymous = True)
  pub = rospy.Publisher('servosAngle',Vector3, queue_size = 10)
  msg = Vector3()
  while not rospy.is_shutdown():
    msg.x = int(calculoAngulo(posx, posy, posz)[0])
    msg.y = int(calculoAngulo(posx, posy, posz)[1])
    msg.z = int(calculoAngulo(posx, posy, posz)[2])
   
    pub.publish(msg)

if __name__ == '__main__':
  main()
