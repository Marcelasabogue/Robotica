#!/usr/bin/env python3
import posix
import numpy as np
from scipy.optimize import fsolve
import rospy
import math as mt
from geometry_msgs.msg import Vector3

l1 = 10
l2 = 8
pm = np.array([+1, -1])


posx = float(input("Introduzca su posicion en x:"))
posy = float(input("Introduzca su posicion en y:"))
posz = float(input("Introduzca su posicion en z:"))


def calculoAngulo(posicionx, posiciony, posicionz):

    #Segundo eje
    anguloServo2 = mt.acos((1/(2*l1*l2))*((posicionx**2 + posiciony**2) - (l1**2 + l2**2)))
    #anguloServo2 = mt.asin(pm[1]*mt.sqrt(1 - (mt.cos(anguloServo2))**2))
    #Primer eje
    anguloServo1 = mt.acos((1/(posicionx**2 + posiciony**2))*(posicionx*(l1 + l2*mt.cos(anguloServo2)) + pm[0]*posiciony*l2*(mt.sqrt(1 - (mt.cos(anguloServo2))**2))))
    anguloServo1 = mt.asin((1/(posicionx**2 + posiciony**2))*(posiciony*(l1 + l2*mt.cos(anguloServo2)) + pm[0]*posicionx*l2*(mt.sqrt(1 - (mt.cos(anguloServo2))**2))))
   
    

   
    #Base
    anguloServo3 = abs(4.5*posz +90)
    #if posy >= 2:
     # return int(anguloServo2*(180/mt.pi)), int(anguloServo1*(180/mt.pi)), int(anguloServo3*(180/mt.pi))
    #elif posy <=2:
    print(int(anguloServo1*(180/mt.pi)),int(anguloServo2*(180/mt.pi)),int(anguloServo3*(180/mt.pi)))
    return int(anguloServo1*(180/mt.pi)),int(anguloServo2*(180/mt.pi)), int(anguloServo3*(180/mt.pi))
 
   
 
def main():
  rospy.init_node('robot_manipulator_planner', anonymous = False)
# rospy.subscriber('posicionCamaras', anonymous = True)
  pub = rospy.Publisher('servosAngle',Vector3, queue_size = 10)
  msg = Vector3()
  loop_rate = rospy.Rate(10)
  while not rospy.is_shutdown():
    msg.x = int(calculoAngulo(posx, posy, posz)[0])
    msg.y = int(calculoAngulo(posx, posy, posz)[1])
    msg.z = int(calculoAngulo(posx, posy, posz)[2])
    pub.publish(msg)
    loop_rate.sleep()

if __name__ == '__main__':
  main()
