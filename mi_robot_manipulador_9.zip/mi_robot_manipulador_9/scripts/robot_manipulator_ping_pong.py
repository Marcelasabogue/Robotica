#!/usr/bin/env python3
import cv2
import rospy
import numpy as np
from std_msgs.msg import  String


redBajo1 = np.array([0,100,20],np.uint8)
redAlto1 = np.array([8,255,255],np.uint8)

redBajo2 = np.array([175,100,20],np.uint8)
redAlto2 = np.array([179,255,255],np.uint8)

coleur = input("Introduzca color")

#def camara():
 # print("entro a camara")
 # vid = cv2.VideoCapture(0)
 #  while(True):
#    ret, frame = vid.read()
#    cv2.imshow('camara robot', frame)
#    if cv2.waitKey(1) & 0xFF == ord('q'):
#        break
#  vid.release()
#  cv2.destroyAllWindows()
 
 
def deteccionColores(color):
  print("entro a deteccion de colores")
  vid = cv2.VideoCapture(0)
  redBajo1 = np.array([0,100,20],np.uint8)
  redAlto1 = np.array([8,255,255],np.uint8)

  redBajo2 = np.array([175,100,20],np.uint8)
  redAlto2 = np.array([179,255,255],np.uint8)
 
 
  azulBajo1 = np.array([100,100,25],np.uint8)
  azulAlto1 = np.array([125,255,255],np.uint8)
 
  amarilloBajo1 = np.array([15,100,25],np.uint8)
  amarilloAlto1 = np.array([45,255,255],np.uint8)
 
 
 
  while True:
      ret, frame = vid.read()
     
      if color == "rojo":
       
        frameHSV = cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
        maskRed1 = cv2.inRange(frameHSV, redBajo1, redAlto1)
        maskRed2 = cv2.inRange(frameHSV, redBajo2, redAlto2)  
        maskRed = cv2.add(maskRed1,maskRed2)
        cv2.imshow('maskRed', maskRed)
        cv2.imshow('frame',frame)
       
      elif color == "azul":
        frameHSV = cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
        maskAzul = cv2.inRange(frameHSV, azulBajo1, azulAlto1)  
        cv2.imshow('maskAzul', maskAzul)
        cv2.imshow('frame',frame)
       
      elif color == "amarillo":
        frameHSV = cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
        maskAmarillo = cv2.inRange(frameHSV, amarilloBajo1, amarilloAlto1)  
        cv2.imshow('maskAmarillo', maskAmarillo)
        cv2.imshow('frame',frame)
     
     
     
      print ("todo bien")
      if cv2.waitKey(1) & 0xFF == ord('q'):
        break    
  vid.release()
  cv2.destroyAllWindows()
   
   
   
   
   
   
def main():
  print("entro a main")
  rospy.init_node('camara', anonymous = True)
#  camara()
  deteccionColores(coleur)
  rospy.spin()
 
if __name__ == '__main__':
  main()
