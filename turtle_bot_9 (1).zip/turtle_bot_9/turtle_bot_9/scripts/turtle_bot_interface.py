#!/usr/bin/env python3

#-------------------------------------------------------------------------------
# IMPORTAR LAS LIBRERÍAS
#-------------------------------------------------------------------------------

from turtle import width
from matplotlib.backends.backend_tkagg import(FigureCanvasTkAgg, NavigationToolbar2Tk)
from cgitb import text
from doctest import master
from fileinput import close
import threading
import rospy
from geometry_msgs.msg import Vector3
import matplotlib.animation as animation
import matplotlib.pyplot as plt
import numpy as np
from tkinter import *

#-------------------------------------------------------------------------------
# INICIALIZA LAS VARIABLES
#-------------------------------------------------------------------------------

# Se declara el vector con las componentes de posición.
global position_message

plt.style.use('dark_background') # Fondo de color negro.

# Se inicializa las variables.
xList = [0]
yList = [0]
theta = [np.pi/2]
dt = 0.1
l= 10
Vr = 0
Vl = 0

base = Tk() # Crea la interfaz.
base.geometry('300x250') # Tamaño de la interfaz.

#-------------------------------------------------------------------------------
# MÉTODOS
#-------------------------------------------------------------------------------

def dataEntrada(data): # Método para leer los datos de posición.
       global Vr  
       global Vl 
       Vr =0
       Vl =0
       if int(data.x)!= 0: # Si el valor de velocidad lineal x es distinta de 0.
              Vr = int(data.x) # Asignar valor positivo de velocidad lineal x a la llanta derecha.
              Vl = int(data.x) # Asignar valor positivo de velocidad lineal x a la llanta izquierda.
       
       if int(data.y) >0: # Si el valor de velocidad angular y es mayor a 0.
              Vr = abs(data.y) # Asignar valor positivo de velocidad angular y a la llanta derecha.
              Vl = -abs(data.y) # Asignar valor negativo de velocidad angular y a la llanta izquierda.

       if int(data.y) <0: # Si el valor de velocidad angular y es menor a 0.
              Vr = -abs(data.y) # Asignar valor negativo de velocidad angular y a la llanta derecha.
              Vl = abs(data.y) # Asignar valor positivo de velocidad angular y a la llanta izquierda.
       
       xList.append( xList[-1]+0.5*(Vr+Vl)*np.cos(theta[-1])*dt) # Se guarda la posición de x.
       yList.append( yList[-1]+0.5*(Vr+Vl)*np.sin(theta[-1])*dt) # Se guarda la posición de y.
       theta.append( theta[-1]+(1/l)*(Vr-Vl)*dt) # Se guarda el ángulo theta.
       print(xList)

def aux(): # Método para crear la gráfica
       figure = plt.gcf()
       figure.set_size_inches(10, 10)
       ani = animation.FuncAnimation(figure, animate, interval=1000) # Función animate que se encarga de graficar.
       plt.xlim(-100,100)
       plt.ylim(-100, 100)
       plt.minorticks_on()
       plt.grid(b=True, which='minor', color='#999999', linestyle='-', alpha=0.2)
       plt.title("Ruta del Robot", 
            fontdict={'family': 'serif', 
            'color' : 'red',
            'weight': 'bold',
            'size': 18}) 
       plt.xlabel("Coordenadana X [cm]", size = 16,)
       plt.ylabel("Coordenadana Y [cm]", size = 16)
       plt.show() # Muestra la gráfica en pantalla.

def animate(i): # Método que anima la gráfica.
       plt.plot(xList, yList) # Se muestra en tiempo real la posición.
       
def pulling():
       rospy.init_node('turtle_bot_interface', anonymous=True) # Inicializa el nodo con el nombre turtle_bot_interface.
       topico_position = "locomotion_arduino" # Variable con el nombre del topico a usar (velocidad).
       rospy.Subscriber(topico_position, Vector3,dataEntrada) # Define el nodo en modo suscriptor con el topico /topico_position de tipo Vector3.
       rospy.spin()

def main():
       t = threading.Thread(target=aux) # Crea un hilo para la funcion aux, la cual atiende los datos que vienen del robot.
       t.start() # Inicializa el hilo.                                               
       pulling()
       
if __name__ == '__main__':
	main()