#!/usr/bin/env python3

#-------------------------------------------------------------------------------
# IMPORTAR LAS LIBRERÍAS
#-------------------------------------------------------------------------------

from tkinter import filedialog, ttk
from unicodedata import name
from turtle_bot_9.srv import cargar_partida, cargar_partidaResponse
from queue import Empty
from turtle import end_fill
import rospy
import sys
import os.path
from pynput import keyboard
from geometry_msgs.msg import Vector3
from tkinter import*

#-------------------------------------------------------------------------------
# INICIALIZA LAS VARIABLES
#-------------------------------------------------------------------------------

# Se declara el vector con las componentes de velocidad de tipo Vector3.
velocity_message = Vector3()

# Presionado y No presionado
def poseCallback(pose_message):
    global x
    global y, z, z
    x = pose_message.x
    y = pose_message.y
    z = pose_message.theta


        
def main():
    global velocity_message
    global ventana
    ventana = Tk() # Crea la interfaz.
    ventana.geometry('200x100') # Tamaño de la interfaz.
    ventana.wm_title('Cargar ruta')
    button = ttk.Button(ventana, text='Open', command=openfile) # Crea el botón de abrir un archivo.
    button.pack(side = BOTTOM, pady = 20,padx = 50)

    ventana.mainloop()
    archivo = open(name, "r")
    lines = archivo.read().split('\n') # Separa la lista por líneas.
    speed_lineal = lines[0] # La primera línea corresponde a la velocidad lineal.
    speed_theta = lines[1] # La segunda línea corresponde a la velocidad angular.

    rospy.init_node('turtle_bot_player') # Inicializa el nodo con el nombre turtle_bot_player.
    # Preguntar.
    
   
    loop_rate = rospy.Rate(10) # 10Hz.
    recreacion_ruta ='locomotion_arduino' # Variable con el nombre del topico a usar (velocidad).
    velocity_publisher = rospy.Publisher(recreacion_ruta,Vector3, queue_size = 10) # Crea un publicador hacia el topico /recreación_ruta de tipo Vector3.
    
    
    for  i in lines:
        key = i
        print('Recreando ruta guardada...')
        if key == '1': # Si se lee un 1.
                velocity_message.x = abs(int(speed_lineal)) # Asignar valor de velocidad lineal a la componente x positiva.
                velocity_message.y = 0 # Asignar valor de velocidad angular en 0.
                velocity_publisher.publish(velocity_message) # Enviar el vector al robot.
            
        elif key == '2': # Si se lee un 2.
                velocity_message.x = -abs(int(speed_lineal)) # Asignar valor de velocidad lineal a la componente x negativa.
                velocity_message.y = 0 # Asignar valor de velocidad angular en 0.
                velocity_publisher.publish(velocity_message) # Enviar el vector al robot.
            
        elif key == '3': # Si se lee un 3.
                velocity_message.y = abs(int(speed_theta)) # Asignar valor de velocidad angular a la componente y positiva.
                velocity_message.x = 0 # Asignar valor de velocidad lineal en 0.
                velocity_publisher.publish(velocity_message) # Enviar el vector al robot.
            
        elif key == '4': # Si se lee un 4.
                velocity_message.y = -abs(int(speed_theta)) # Asignar valor de velocidad angular a la componente y negativa.
                velocity_message.x = 0 # Asignar valor de velocidad lineal en 0.
                velocity_publisher.publish(velocity_message) # Enviar el vector al robot.
        elif key == '': # Si se lee nada.
                speed_lineal = 0 # Asignar valor de velocidad lineal en 0.
                speed_theta = 0 # Asignar valor de velocidad angular en 0.
                sys.exit()
        loop_rate.sleep()


def openfile(): # Método para abiri el archivo.
        global name 
        name = filedialog.askopenfilename()
        ventana.destroy()
        return name; 

if __name__ == "__main__":
	main()

